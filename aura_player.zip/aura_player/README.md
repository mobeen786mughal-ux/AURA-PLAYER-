# Aura Player

All-format video player built with Flutter + VLC.

## Structure
- pubspec.yaml          -> dependencies
- lib/main.dart         -> app entry
- lib/models/           -> data models
- lib/services/         -> video scanner
- lib/screens/          -> UI screens
- lib/widgets/          -> reusable widgets

## Build
flutter create .
flutter pub get
flutter build apk --release
