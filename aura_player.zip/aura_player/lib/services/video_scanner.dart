import 'package:photo_manager/photo_manager.dart';
import '../models/video_item.dart';

class VideoScanner {
  static Future<List<VideoItem>> scanVideos() async {
    final permission = await PhotoManager.requestPermissionExtend();
    if (!permission.isAuth && !permission.hasAccess) {
      return [];
    }

    final albums = await PhotoManager.getAssetPathList(
      type: RequestType.video,
      onlyAll: true,
    );
    if (albums.isEmpty) return [];

    final assets = await albums.first.getAssetListRange(start: 0, end: 500);
    final List<VideoItem> videos = [];

    for (final asset in assets) {
      final file = await asset.file;
      if (file == null) continue;
      videos.add(VideoItem(
        id: asset.id,
        title: asset.title ?? 'Unknown',
        path: file.path,
        duration: Duration(seconds: asset.duration),
        size: await file.length(),
        asset: asset,
      ));
    }
    return videos;
  }
}
