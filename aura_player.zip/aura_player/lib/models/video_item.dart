import 'package:photo_manager/photo_manager.dart';

class VideoItem {
  final String id;
  final String title;
  final String path;
  final Duration duration;
  final int size;
  final AssetEntity asset;

  VideoItem({
    required this.id,
    required this.title,
    required this.path,
    required this.duration,
    required this.size,
    required this.asset,
  });

  String get sizeText {
    if (size < 1024 * 1024) return '${(size / 1024).toStringAsFixed(1)} KB';
    if (size < 1024 * 1024 * 1024) {
      return '${(size / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(size / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  String get durationText {
    final h = duration.inHours;
    final m = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = duration.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }
}
