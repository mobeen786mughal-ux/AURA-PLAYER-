import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:screen_brightness/screen_brightness.dart';
import 'package:volume_controller/volume_controller.dart';

class PlayerScreen extends StatefulWidget {
  final String videoPath;
  final String title;
  const PlayerScreen({super.key, required this.videoPath, this.title = 'Video'});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late VideoPlayerController _controller;
  bool _isLocked = false;
  bool _showControls = true;
  
  // Gestures State
  double _brightness = 0.5;
  double _volume = 0.5;
  String _gestureText = "";
  bool _showGestureIndicator = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.file(File(widget.videoPath))
      ..initialize().then((_) {
        setState(() {});
        _controller.play();
        _initSystemSettings();
      });
  }

  Future<void> _initSystemSettings() async {
    _brightness = await ScreenBrightness().current;
    _volume = await VolumeController.instance.getVolume();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onVerticalDragUpdate(DragUpdateDetails details, double width) {
    if (_isLocked) return;
    
    double delta = details.primaryDelta! / 200; // Sensitivity
    
    if (details.globalPosition.dx < width / 2) {
      // Left side = Brightness
      setState(() {
        _brightness = (_brightness - delta).clamp(0.0, 1.0);
        ScreenBrightness().setScreenBrightness(_brightness);
        _gestureText = "Brightness: ${(_brightness * 100).toInt()}%";
        _showGestureIndicator = true;
      });
    } else {
      // Right side = Volume
      setState(() {
        _volume = (_volume - delta).clamp(0.0, 1.0);
        VolumeController.instance.setVolume(_volume);
        _gestureText = "Volume: ${(_volume * 100).toInt()}%";
        _showGestureIndicator = true;
      });
    }
  }

  void _onVerticalDragEnd(DragEndDetails details) {
    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted) setState(() => _showGestureIndicator = false);
    });
  }

  void _onDoubleTap(double dx, double width) {
    if (_isLocked) return;
    if (dx < width / 2) {
      // Peeche jao
      final newPos = _controller.value.position - const Duration(seconds: 10);
      _controller.seekTo(newPos.isNegative ? Duration.zero : newPos);
      _showCenterToast('-10s ⏪');
    } else {
      // Aage jao
      final newPos = _controller.value.position + const Duration(seconds: 10);
      _controller.seekTo(newPos);
      _showCenterToast('+10s ⏩');
    }
  }

  void _showCenterToast(String text) {
    setState(() { _gestureText = text; _showGestureIndicator = true; });
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) setState(() => _showGestureIndicator = false);
    });
  }

  String _formatDuration(Duration d) {
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    String twoDigitMinutes = twoDigits(d.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(d.inSeconds.remainder(60));
    return "${twoDigits(d.inHours)}:$twoDigitMinutes:$twoDigitSeconds";
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            // Gesture Detector for Brightness/Volume/Seek
            GestureDetector(
              onVerticalDragUpdate: (details) => _onVerticalDragUpdate(details, size.width),
              onVerticalDragEnd: _onVerticalDragEnd,
              onDoubleTapDown: (details) => _onDoubleTap(details.localPosition.dx, size.width),
              onTap: () {
                if (!_isLocked) setState(() => _showControls = !_showControls);
              },
              child: Center(
                child: _controller.value.isInitialized
                    ? AspectRatio(
                        aspectRatio: _controller.value.aspectRatio,
                        child: VideoPlayer(_controller),
                      )
                    : const CircularProgressIndicator(color: Colors.purpleAccent),
              ),
            ),

            // Gesture Indicator (Brightness/Volume)
            if (_showGestureIndicator)
              Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    _gestureText,
                    style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
              ),

            // Top Controls (Title & Lock)
            if (_showControls && !_isLocked)
              Positioned(
                top: 0, left: 0, right: 0,
                child: Container(
                  color: Colors.black54,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  child: Row(
                    children: [
                      IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context)),
                      Expanded(
                        child: Text(widget.title, style: const TextStyle(color: Colors.white, fontSize: 16), overflow: TextOverflow.ellipsis),
                      ),
                      IconButton(icon: const Icon(Icons.lock_open, color: Colors.white), onPressed: () {
                        setState(() { _isLocked = true; _showControls = false; });
                      }),
                    ],
                  ),
                ),
              ),

            // Unlock Button (Agar Locked hai)
            if (_isLocked)
              Positioned(
                top: 20, right: 20,
                child: IconButton(
                  icon: const Icon(Icons.lock, color: Colors.white, size: 30),
                  onPressed: () => setState(() { _isLocked = false; _showControls = true; }),
                ),
              ),

            // Bottom Controls (Play/Pause, Seek, Speed)
            if (_showControls && !_isLocked)
              Positioned(
                bottom: 0, left: 0, right: 0,
                child: Container(
                  color: Colors.black54,
                  padding: const EdgeInsets.only(bottom: 10, top: 5),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Seek Bar
                      Row(
                        children: [
                          Text(_formatDuration(_controller.value.position), style: const TextStyle(color: Colors.white, fontSize: 12)),
                          Expanded(
                            child: VideoProgressIndicator(
                              _controller,
                              allowScrubbing: true,
                              colors: const VideoProgressColors(
                                playedColor: Colors.purpleAccent,
                                bufferedColor: Colors.white54,
                                backgroundColor: Colors.grey,
                              ),
                            ),
                          ),
                          Text(_formatDuration(_controller.value.duration), style: const TextStyle(color: Colors.white, fontSize: 12)),
                        ],
                      ),
                      // Buttons
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          // Speed Button
                          PopupMenuButton<double>(
                            initialValue: _controller.value.playbackSpeed,
                            icon: const Icon(Icons.speed, color: Colors.white),
                            onSelected: (value) {
                              _controller.setPlaybackSpeed(value);
                              setState(() {});
                            },
                            itemBuilder: (context) => [0.5, 1.0, 1.5, 2.0].map((e) => PopupMenuItem(value: e, child: Text('${e}x'))).toList(),
                          ),
                          // Play/Pause
                          IconButton(
                            iconSize: 50,
                            icon: Icon(_controller.value.isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled, color: Colors.white),
                            onPressed: () {
                              setState(() {
                                _controller.value.isPlaying ? _controller.pause() : _controller.play();
                              });
                            },
                          ),
                          // Full Screen (Placeholder)
                          IconButton(
                            icon: const Icon(Icons.fullscreen, color: Colors.white),
                            onPressed: () {},
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
