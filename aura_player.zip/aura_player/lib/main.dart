import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const AuraPlayerApp());
}

class AuraPlayerApp extends StatelessWidget {
  const AuraPlayerApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aura Player',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: Colors.purpleAccent,
        scaffoldBackgroundColor: const Color(0xFF121212),
      ),
      home: const HomeScreen(),
    );
  }
}
